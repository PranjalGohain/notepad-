name 'mysql-windows'
maintainer 'Deepak Sihag'
maintainer_email 'sihag.deepak@gmail.com'
description 'Provides mysql server for windows'

version '5.5.43'

supports 'windwos'

depends 'windows'
